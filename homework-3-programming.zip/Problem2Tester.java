public class Problem2Tester{
	public static void main(String[] args){
		BetterBST<Integer> i = new BetterBST<>();
		i.insert(100);
		i.insert(104);
		i.insert(98);
		i.insert(10);
		i.insert(920);
		i.insert(300);
		i.insert(8);
		i.prettyPrint();
	}
}
